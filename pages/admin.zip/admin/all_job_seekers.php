<?php
require '../db_connection.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// حذف المستخدم
if (isset($_GET['delete'])) {
    $user_id = intval($_GET['delete']);
    try {
        $stmt = $conn->prepare("DELETE FROM users WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $_SESSION['success_message'] = 'تم حذف المستخدم بنجاح.';
        header('Location: all_job_seekers.php');
        exit();
    } catch (mysqli_sql_exception $e) {
        $_SESSION['error_message'] = 'حدث خطأ أثناء الحذف: ' . $e->getMessage();
        header('Location: all_job_seekers.php');
        exit();
    }
}

// البحث والفلترة
$search = $_GET['search'] ?? '';
$sort_by = $_GET['sort_by'] ?? 'name';
$sort_order = $_GET['sort_order'] ?? 'asc';

$allowed_sort = ['name', 'email', 'location'];
$allowed_order = ['asc', 'desc'];

$query = "SELECT user_id, name, email, phone, cv_link, location FROM users WHERE role = 'employee'";

if (!empty($search)) {
    $search = $conn->real_escape_string($search);
    $query .= " AND (name LIKE '%$search%' OR email LIKE '%$search%')";
}

if (in_array($sort_by, $allowed_sort) && in_array($sort_order, $allowed_order)) {
    $query .= " ORDER BY $sort_by $sort_order";
}

$result = $conn->query($query);
$employees = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
  <meta charset="UTF-8">
  <title>قائمة طالبي الوظيفة</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>

<body>
  <?php include 'includes/admin_header.php'; ?>

  <div class="admin-container">

    <div class="container mt-4">
      <h2 class="mb-4">قائمة طالبي العمل</h2>

      <?php if (isset($_SESSION['success_message'])): ?>
      <div class="alert alert-success"><?= $_SESSION['success_message']; unset($_SESSION['success_message']); ?></div>
      <?php endif; ?>

      <?php if (isset($_SESSION['error_message'])): ?>
      <div class="alert alert-danger"><?= $_SESSION['error_message']; unset($_SESSION['error_message']); ?></div>
      <?php endif; ?>

      <!-- Search and Filters -->
      <form class="admin-search mb-4" method="GET">
        <div class="row">
          <div class="col-md-4">
            <div class="input-group">
              <input type="text" class="form-control" name="search" value="<?php echo htmlspecialchars($search); ?>"
                placeholder="Search job seekers...">
              <button class="btn btn-outline-secondary" type="submit">Search</button>
            </div>
          </div>
          <div class="col-md-4">
            <select class="form-select" name="sort_by">
              <option value="ja.applied_at" <?php echo $sort_by === 'ja.applied_at' ? 'selected' : ''; ?>>Date Applied
              </option>
              <option value="u.name" <?php echo $sort_by === 'u.name' ? 'selected' : ''; ?>>Name</option>
              <option value="j.title" <?php echo $sort_by === 'j.title' ? 'selected' : ''; ?>>Job Title</option>
            </select>
          </div>
          <div class="col-md-2">
            <select class="form-select" name="sort_order">
              <option value="asc" <?php echo $sort_order === 'asc' ? 'selected' : ''; ?>>Ascending</option>
              <option value="desc" <?php echo $sort_order === 'desc' ? 'selected' : ''; ?>>Descending</option>
            </select>
          </div>
        </div>
      </form>

      <!-- جدول عرض المستخدمين -->
      <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle text-center">
          <thead class="table-light">
            <tr>
              <th>الاسم</th>
              <th>البريد الإلكتروني</th>
              <th>رقم الهاتف</th>
              <th>الموقع</th>
              <th>إجراءات</th>
            </tr>
          </thead>
          <tbody>
            <?php if (count($employees) > 0): ?>
            <?php foreach ($employees as $emp): ?>
            <tr>
              <td><?= htmlspecialchars($emp['name']) ?></td>
              <td><?= htmlspecialchars($emp['email']) ?></td>
              <td><?= htmlspecialchars($emp['phone']) ?></td>
              <td><?= htmlspecialchars($emp['location']) ?></td>
              <td>
                <a href="?delete=<?= $emp['user_id'] ?>" class="btn btn-sm btn-danger"
                  onclick="return confirm('هل أنت متأكد من حذف هذا المستخدم؟');">
                  <i class="bi bi-trash"></i> حذف
                </a>
              </td>
            </tr>
            <?php endforeach; ?>
            <?php else: ?>
            <tr>
              <td colspan="6" class="text-muted">لا توجد نتائج.</td>
            </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>